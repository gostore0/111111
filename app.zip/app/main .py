from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Request, Form
from fastapi.middleware.cors import CORSMiddleware
from app.database.database import init_db
from app.auth.auth import auth_router
from app.utils.auth_utils import get_current_user
from app.features.file import file_router
from app.features.rag import retrieve_and_generate
from app.database.file_queries import get_files_by_user, delete_file_by_id, add_file
from app.database.queries import create_chat, get_chats_by_user
from app.middlewares.performance_middleware import performance_middleware
from uuid import uuid4
import os
import aiofiles
from app.utils.pdf_utils import extract_text_from_pdf
from supabase import create_client, Client
import json
from contextlib import asynccontextmanager
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

# Supabase client
url: str = "http://aws-0-eu-central-1.pooler.supabase.com"  # أدخل رابط Supabase الخاص بك
key: str = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50ZmNidG1yZ3FqbXBocHZoY3N1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNTg2NzQ2NSwiZXhwIjoyMDUxNDQzNDY1fQ.MgRMBJi_Zg__hrrJMGZikkIRt-oeGmO9FBef_JyAS5I"  # أدخل مفتاح API الخاص بـ Supabase

supabase: Client = create_client(url, key)

UPLOAD_DIR = "uploads"
DATABASE_URL = "postgresql+asyncpg://postgres.ntfcbtmrgqjmphpvhcsu:Pdfapp123456##@aws-0-eu-central-1.pooler.supabase.com:5432/postgres"

if not DATABASE_URL:
    raise ValueError("DATABASE_URL environment variable not set")

engine = create_async_engine(DATABASE_URL, echo=True)

async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

@asynccontextmanager
async def lifespan(app: FastAPI):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    await init_db()
    yield

app = FastAPI(lifespan=lifespan)

# تمكين CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # السماح بالطلبات من تطبيق React
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# تضمين routers
app.include_router(auth_router, prefix="/auth", tags=["Authentication"])
app.include_router(file_router, prefix="", tags=["File"])

# إضافة middleware
app.middleware("http")(performance_middleware)
@app.get("/")  #  تمت إضافة endpoint  ل /
async def root():
    return {"message": "Hello World"}
@app.get("/files")
async def get_files(user: dict = Depends(get_current_user)):
    files = await get_files_by_user(user["email"], supabase)
    return [{"id": file.id, "name": file.file_path.split("/")[-1]} for file in files]

@app.delete("/files/{file_id}")
async def delete_file(file_id: str, user: dict = Depends(get_current_user)):
    await delete_file_by_id(file_id, supabase)
    return {"message": "File deleted successfully"}

@app.get("/chats")
async def get_user_chats(user: dict = Depends(get_current_user)):
    chats = await get_chats_by_user(user["email"], supabase)
    chats_data = [
        {"id": chat.id, "messages": json.loads(chat.messages)} for chat in chats
    ]
    return chats_data

@app.post("/generate/")
async def generate_response(
    prompt: str = Form(...),
    selected_files: list = Form([]),
    user: dict = Depends(get_current_user),
):
    response = await retrieve_and_generate(prompt, user["email"], selected_files)

    chat_id = str(uuid4())
    await create_chat(
        chat_id,
        json.dumps(
            [
                {"role": "user", "content": prompt},
                {"role": "assistant", "content": response},
            ]
        ),
        user["email"],
        supabase,
    )

    return {"message": "Response generated", "response": response}

@file_router.post("/upload/")
async def upload_file(
    file: UploadFile = File(...), user: dict = Depends(get_current_user)
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    file_id = str(uuid4())
    #  استبدل  file.filename  ب  file.filename.encode('utf-8').decode('unicode_escape')
    file_path = os.path.join(UPLOAD_DIR, file_id + "_" + file.filename.encode('utf-8').decode('unicode_escape'))
    os.makedirs(UPLOAD_DIR, exist_ok=True)

    async with aiofiles.open(file_path, "wb") as f:
        while content := await file.read(1024):
            await f.write(content)

    file_path_supabase = f"{user['email']}/{file_id}_{file.filename.encode('utf-8').decode('unicode_escape')}"
    with open(file_path, "rb") as f:
        res = supabase.storage.from_("pdfs").upload(file_path_supabase, f)

    content = extract_text_from_pdf(file_path)
    await add_file(file_id, file_path_supabase, content, user["email"], supabase)

    return {"message": "File uploaded successfully", "file_id": file_id}