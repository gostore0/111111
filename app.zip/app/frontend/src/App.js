import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  FiX,
  FiUpload,
  FiTrash2,
  FiCheckSquare,
  FiSquare,
  FiMenu,
  FiFile,
  FiChevronRight,
} from 'react-icons/fi';
import { motion } from 'framer-motion';
import { createClient } from '@supabase/supabase-js';
import * as pdfjsLib from 'pdfjs-dist/build/pdf';

pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseKey = process.env.REACT_APP_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

function App() {
  // State variables
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isFilesOpen, setIsFilesOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [history, setHistory] = useState([]);
  const [files, setFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [user, setUser] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [loginError, setLoginError] = useState(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showRegisterForm, setShowRegisterForm] = useState(false);
  const [isLoginFormVisible, setIsLoginFormVisible] = useState(false);

  // Refs
  const messagesEndRef = useRef(null);
  const filesDrawerRef = useRef(null);
  const fileInputRef = useRef(null);
  const historyDrawerRef = useRef(null);

  // --- Authentication ---

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    const storedToken = localStorage.getItem("token");
    if (storedUser && storedToken) {
      const userObject = JSON.parse(storedUser);
      setUser({
        email: userObject.email,
        access_token: userObject.access_token,
      });
    }
  }, []);

  const login = async (email, password) => {
    setLoginError(null);
    console.log("Attempting to login with:", email, password);
    try {
      const {
        user: loggedInUser,
        session,
        error,
      } = await supabase.auth.signInWithPassword({
        email: email,
        password: password,
      });
  
      console.log("Supabase signIn result:", { loggedInUser, session, error });
  
      if (error) {
        throw new Error(error.message || 'Login failed');
      }
  
      if (loggedInUser && session && session.access_token) {
        setUser({ email: loggedInUser.email, access_token: session.access_token });
        localStorage.setItem(
          'user',
          JSON.stringify({ email: loggedInUser.email, access_token: session.access_token })
        );
        localStorage.setItem('token', session.access_token);
        setIsLoginFormVisible(false);
      } else if (!loggedInUser) {
        throw new Error('Login failed: No user data received.');
      } else {
        throw new Error('Login failed: No access token received.');
      }
    } catch (error) {
      console.error("Error during login:", error);
      setLoginError(error.message);
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    localStorage.removeItem('user');
    localStorage.removeItem('token');
  };

  const handleOAuthLogin = async (provider) => {
    const { user, session, error } = await supabase.auth.signInWithOAuth({
      provider: provider,
    });

    if (error) {
      console.error("OAuth login error:", error);
      setLoginError(error.message);
    } else if (session && session.access_token) {
      setUser({ email: user.email, access_token: session.access_token });
      localStorage.setItem(
        "user",
        JSON.stringify({
          email: user.email,
          access_token: session.access_token,
        })
      );
      localStorage.setItem("token", session.access_token);
      setIsLoginFormVisible(false);
    }
  };

  // --- Handlers ---

  const handleMenuClick = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleFilesClick = () => {
    setIsFilesOpen(!isFilesOpen);
  };

  const handleSendMessage = async (newMessage) => {
    setMessages([...messages, { role: 'user', content: newMessage }]);

    try {
        const response = await fetch('http://localhost:8000/generate/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: `Bearer ${localStorage.getItem('token')}`,
            },
            body: `prompt=${encodeURIComponent(
                newMessage
            )}&selected_files=${encodeURIComponent(JSON.stringify(selectedFiles))}`,
        });

        if (response.ok) {
            const data = await response.json();
            setMessages((prevMessages) => [
                ...prevMessages,
                { role: 'assistant', content: data.response },
            ]);
        } else {
            const errorData = await response.json();
            console.error('Failed to send message:', errorData);
        }
    } catch (error) {
        console.error('Error sending message:', error);
    }
};

const handleFileSelect = (fileId) => {
    setSelectedFiles((prevSelectedFiles) =>
        prevSelectedFiles.includes(fileId)
            ? prevSelectedFiles.filter((id) => id !== fileId)
            : [...prevSelectedFiles, fileId]
    );
};

const handleChatSelect = (chatId) => {
    const selectedChat = history.find((chat) => chat.id === chatId);
    if (selectedChat) {
        setMessages(
            selectedChat.messages.map((message) => ({
                role: message.includes('User:') ? 'user' : 'assistant',
                content: message.replace(/User: |Assistant: /, ''),
            }))
        );
    }
};

const handleFileUpload = async (event) => {
    if (!user) {
        setIsLoginFormVisible(true);
        return;
    }

    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    setUploadProgress(0);

    const fileId = generateUniqueFileId();
    const fileName = file.name.replace(/[^a-zA-Z0-9_.-]/g, '_');
    const filePath = `${user.email}/${fileId}_${fileName}`;

    const { error: uploadError } = await supabase.storage
        .from('pdfs')
        .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false,
        });

    if (uploadError) {
        console.error('File upload failed:', uploadError);
        setIsUploading(false);
        return;
    }

    const content = await extractTextFromPdf(file);
    await addFileToDatabase(fileId, filePath, content, user.email);

    setSelectedFiles((prevSelectedFiles) => [...prevSelectedFiles, fileId]);
    fetchFiles();
    setIsUploading(false);
};

function generateUniqueFileId() {
    return Math.random().toString(36).substring(2, 15);
}

async function extractTextFromPdf(file) {
    const reader = new FileReader();
    return new Promise((resolve) => {
        reader.onload = async (event) => {
            const typedArray = new Uint8Array(event.target.result);
            const pdf = await pdfjsLib.getDocument(typedArray).promise;
            let fullText = '';
            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const textContent = await page.getTextContent();
                const pageText = textContent.items.map((item) => item.str).join(' ');
                fullText += pageText + '\n';
            }
            resolve(fullText);
        };
        reader.readAsArrayBuffer(file);
    });
}

async function addFileToDatabase(fileId, filePath, content, authorEmail) {
    try {
        const { error } = await supabase.from('files').insert([
            {
                id: fileId,
                file_path: filePath,
                content: content,
                author_email: authorEmail,
            },
        ]);

        if (error) {
            console.error('Error adding file to database:', error);
        }
    } catch (error) {
        console.error('Error adding file to database:', error);
    }
}

const handleDeleteFile = async (fileId) => {
    try {
        const fileToDelete = files.find((file) => file.id === fileId);
        if (!fileToDelete) {
            console.error('File not found');
            return;
        }

        const { error: deleteError } = await supabase
            .from('files')
            .delete()
            .eq('id', fileId);

        if (deleteError) {
            console.error('Error deleting file from database:', deleteError);
            return;
        }

        const { error: storageError } = await supabase.storage
            .from('pdfs')
            .remove([fileToDelete.file_path]);

        if (storageError) {
            console.error('Error deleting file from storage:', storageError);
            return;
        }

        fetchFiles();
        setSelectedFiles(selectedFiles.filter((id) => id !== fileId));
    } catch (error) {
        console.error('Error deleting file:', error);
    }
};

// --- Effects ---

useEffect(() => {
const handleOutsideClick = (event, ref, closeFunction) => {
  if (ref.current && !ref.current.contains(event.target)) {
    closeFunction();
  }
};

const handleMenuClickOutside = (event) => {
  handleOutsideClick(event, historyDrawerRef, () => setIsMenuOpen(false));
};

const handleFilesClickOutside = (event) => {
  handleOutsideClick(event, filesDrawerRef, () => setIsFilesOpen(false));
};

if (isMenuOpen) {
  document.addEventListener('mousedown', handleMenuClickOutside);
}
if (isFilesOpen) {
  document.addEventListener('mousedown', handleFilesClickOutside);
}

return () => {
  document.removeEventListener('mousedown', handleMenuClickOutside);
  document.removeEventListener('mousedown', handleFilesClickOutside);
};
}, [isMenuOpen, isFilesOpen]);

useEffect(() => {
messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
}, [messages]);

const fetchFiles = useCallback(async () => {
try {
    const { data: filesData, error } = await supabase
        .from('files')
        .select('*')
        .eq('author_email', user.email);

    if (error) {
        console.error('Failed to fetch files:', error);
        return;
    }

    const filesWithNames = await Promise.all(
        filesData.map(async (file) => {
            const { data: fileUrl, error: urlError } = await supabase.storage
                .from('pdfs')
                .getPublicUrl(file.file_path);

            if (urlError) {
                console.error('Error getting file URL:', urlError);
                return null;
            }

            return {
                ...file,
                name: file.file_path.split('/').pop().split('_').slice(1).join('_'),
                url: fileUrl.publicUrl,
            };
        })
    );

    setFiles(filesWithNames.filter((file) => file !== null));
} catch (error) {
    console.error('Error fetching files:', error);
}
}, [user]);

useEffect(() => {
const fetchData = async () => {
  if (user) {
    try {
      const { data: chatsData, error: chatsError } = await supabase
        .from('chats')
        .select('*')
        .eq('author_email', user.email);

      if (chatsError) {
        console.error('Failed to fetch history:', chatsError);
      } else {
        setHistory(chatsData);
      }

      fetchFiles();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }
};

fetchData();
}, [user, fetchFiles]);

// --- Components ---

const Navbar = ({ onMenuClick, logout }) => (
<div className="bg-gray-800 text-white py-2 px-4 flex justify-between items-center">
  <div className="flex items-center space-x-3">
    <button onClick={onMenuClick} className="text-white">
      <FiMenu size={24} />
    </button>
    <div className="text-lg font-semibold">Internal Knowledge Base</div>
  </div>
  {user ? (
    <div className="group relative">
      <button
        className="flex items-center space-x-2 py-1 px-2 rounded-md hover:bg-gray-700"
      >
        <span className="text-sm">{user.email}</span>
        <FiMenu size={16} className="text-gray-400" />
      </button>
      <div className="absolute right-0 mt-2 w-48 bg-gray-800 border border-gray-700 rounded-md shadow-lg p-2 hidden group-hover:block">
        <button
          onClick={logout}
          className="w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-red-700 rounded-md"
        >
          Sign out
        </button>
      </div>
    </div>
  ) : (
    <button
      onClick={() => setIsLoginFormVisible(true)}
      className="text-sm p-1 px-2 bg-gray-700 rounded-md hover:bg-gray-600"
    >
      Login
    </button>
  )}
</div>
);

const suggestedActions = [
{
  title: "What's the summary",
  label: 'of these documents?',
  action: "what's the summary of these documents?",
},
{
  title: 'Who is the author',
  label: 'of these documents?',
  action: 'who is the author of these documents?',
},
];

  const ChatArea = () => (
    <div className="flex flex-col h-full bg-gray-900">
      <div className="flex-1 overflow-y-auto">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full">
            <div className="grid grid-cols-2 gap-4">
              {suggestedActions.map((action, index) => (
                <motion.button
                  key={index}
                  className="bg-gray-700 text-white px-4 py-2 rounded-lg shadow-md hover:bg-gray-600"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => handleSendMessage(action.action)}
                >
                  <span className="font-medium">{action.title}</span>
                  <br />
                  <span className="text-sm">{action.label}</span>
                </motion.button>
              ))}
            </div>
          </div>
        )}
        {messages.map((message, index) => (
          <motion.div
            key={index}
            className={`flex items-start p-4 ${
              message.role === 'user' ? 'justify-end' : ''
            }`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div
              className={`rounded-lg p-3 ${
                message.role === 'user'
                  ? 'bg-blue-500 text-white ml-8'
                  : 'bg-gray-700 text-white mr-8'
              }`}
            >
              <p className="text-sm">{message.content}</p>
            </div>
          </motion.div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          const newMessage = event.target.elements.message.value;
          if (newMessage.trim()) {
            handleSendMessage(newMessage);
            event.target.reset();
          }
        }}
        className="p-4 flex items-center space-x-2"
      >
        <input
          type="text"
          name="message"
          placeholder="Send a message..."
          className="flex-1 border border-gray-700 px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-800 text-white"
        />
        <div className="relative">
          <button
            type="button"
            onClick={handleFilesClick}
            className="p-2 rounded-md bg-gray-700 hover:bg-gray-600"
          >
            <FiFile size={20} className="text-white" />
            <span className="absolute -top-2 -right-2 bg-blue-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
              {selectedFiles.length}
            </span>
          </button>
        </div>
      </form>
    </div>
  );
<button onClick={() => handleOAuthLogin('google')}>Login with Google</button>
  const FilesDrawer = () => (
    <motion.div
      className={`fixed top-0 right-0 h-full w-80 bg-gray-800 text-white shadow-lg p-4 z-50 overflow-y-auto ${
        isFilesOpen ? '' : 'hidden'
      }`}
      initial={{ x: '100%' }}
      animate={{ x: isFilesOpen ? '0%' : '100%' }}
      transition={{ type: 'spring', stiffness: 200, damping: 30 }}
      ref={filesDrawerRef}
    >
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">Files</h2>
        <button
          onClick={() => setIsFilesOpen(false)}
          className="hover:bg-gray-700 p-2 rounded-md"
        >
          <FiX size={20} />
        </button>
      </div>
      <input
        type="file"
        className="hidden"
        accept=".pdf"
        onChange={handleFileUpload}
        ref={fileInputRef}
      />
      <button
        onClick={() => {
          if (!user) {
            setIsLoginFormVisible(true);
          } else {
            fileInputRef.current.click();
          }
        }}
        className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md mb-4 flex items-center justify-center"
      >
        <FiUpload size={16} className="mr-2" />
        Upload PDF
      </button>
      {isUploading && (
        <div className="mb-4">
          <div className="bg-gray-700 rounded-full h-2">
            <div
              className="bg-blue-500 h-full rounded-full"
              style={{ width: `${uploadProgress}%` }}
            ></div>
          </div>
          <p className="text-sm text-gray-400 mt-1">
            Uploading... {Math.round(uploadProgress)}%
          </p>
        </div>
      )}

      <ul>
        {files.map((file) => (
          <li
            key={file.id}
            className="flex items-center justify-between py-2 border-b border-gray-700"
          >
            <button
              onClick={() => handleFileSelect(file.id)}
              className="flex items-center space-x-2"
            >
              {selectedFiles.includes(file.id) ? (
                <FiCheckSquare size={16} className="text-blue-500" />
              ) : (
                <FiSquare size={16} className="text-gray-500" />
              )}
              <span className="text-sm">{file.name}</span>
            </button>
            <button
              onClick={() => handleDeleteFile(file.id)}
              className="hover:bg-red-700 p-1 rounded-md"
            >
              <FiTrash2 size={16} className="text-red-500" />
            </button>
          </li>
        ))}
      </ul>
      <div className="mt-4">
        <p className="text-sm text-gray-400">
          Selected files: {selectedFiles.length} / {files.length}
        </p>
      </div>
    </motion.div>
  );

  const HistoryDrawer = () => (
    <motion.div
      className={`fixed top-0 left-0 h-full w-80 bg-gray-800 text-white shadow-lg p-4 z-40 overflow-y-auto ${
        isMenuOpen ? '' : 'hidden'
      }`}
      initial={{ x: '-100%' }}
      animate={{ x: isMenuOpen ? '0%' : '-100%' }}
      transition={{ type: 'spring', stiffness: 200, damping: 30 }}
      ref={historyDrawerRef}
    >
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold">History</h2>
        <button
          onClick={() => setIsMenuOpen(false)}
          className="hover:bg-gray-700 p-2 rounded-md"
        >
          <FiX size={20} />
        </button>
      </div>
      <ul>
        {history.map((chat) => (
          <li
            key={chat.id}
            className="flex items-center justify-between py-2 border-b border-gray-700 cursor-pointer hover:bg-gray-700"
            onClick={() => {
              handleChatSelect(chat.id);
              setIsMenuOpen(false);
            }}
          >
            <span className="text-sm">
              {chat.messages[0]?.content || 'New Chat'}
            </span>
            <FiChevronRight size={16} />
          </li>
        ))}
      </ul>
    </motion.div>
  );

  const AuthForm = () => (
    <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
      <div className="bg-gray-800 p-8 rounded-lg shadow-md w-96">
        <h2 className="text-2xl font-semibold mb-4 text-center">
          {showRegisterForm ? 'Register' : 'Login'}
        </h2>
        {loginError && (
          <p className="text-red-500 text-sm mb-4">{loginError}</p>
        )}
        <form
          onSubmit={(event) => {
            event.preventDefault();
            if (showRegisterForm) {
              if (password !== confirmPassword) {
                setLoginError('Passwords do not match.');
                return;
              }
              handleRegister(email, password);
            } else {
              login(email, password);
            }
          }}
        >
          <div className="mb-4">
            <label
              htmlFor="email"
              className="block mb-2 text-sm font-medium text-gray-300"
            >
              Email
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700 text-white"
              required
            />
          </div>
          <div className="mb-4">
            <label
              htmlFor="password"
              className="block mb-2 text-sm font-medium text-gray-300"
            >
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700 text-white"
              required
            />
          </div>
          {showRegisterForm && (
            <div className="mb-6">
              <label
                htmlFor="confirmPassword"
                className="block mb-2 text-sm font-medium text-gray-300"
              >
                Confirm Password
              </label>
              <input
                type="password"
                id="confirmPassword"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-3 py-2 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-700 text-white"
                required
              />
            </div>
          )}
          <button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md"
          >
            {showRegisterForm ? 'Register' : 'Login'}
          </button>
        </form>
        <div className="mt-4 text-center">
          {showRegisterForm ? (
            <button
              onClick={() => setShowRegisterForm(false)}
              className="text-sm text-blue-500 hover:underline"
            >
              Already have an account? Login
            </button>
          ) : (
            <button
              onClick={() => setShowRegisterForm(true)}
              className="text-sm text-blue-500 hover:underline"
            >
              Don't have an account? Register
            </button>
          )}
        </div>
        <button
          onClick={() => setIsLoginFormVisible(false)}
          className="absolute top-2 right-2 hover:bg-gray-700 p-2 rounded-md"
        >
          <FiX size={20} />
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {isLoginFormVisible && <AuthForm />}
      {isMenuOpen && (
        <HistoryDrawer
          isOpen={isMenuOpen}
          onClose={() => setIsMenuOpen(false)}
          history={history}
          onChatSelect={handleChatSelect}
        />
      )}
      <div className="flex-1 flex flex-col">
        <Navbar />
        <ChatArea />
        {isFilesOpen && (
          <FilesDrawer
            onClose={() => setIsFilesOpen(false)}
            onFileSelect={handleFileSelect}
            selectedFiles={selectedFiles}
            files={files}
            onFileUpload={handleFileUpload}
            onDeleteFile={handleDeleteFile}
          />
        )}
      </div>
    </div>
  );
}

export default App;