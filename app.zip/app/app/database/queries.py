from app.models.chat import Chat
from sqlalchemy.future import select
from app.models.user import User
from app.database.database import async_session  #  استيراد async_session

async def get_user(email: str, supabase):
    async with async_session() as session:
        result = await session.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

async def create_chat(chat_id: str, messages: str, author_email: str, supabase):
    async with async_session() as session:
        new_chat = Chat(id=chat_id, messages=messages, author_email=author_email)
        session.add(new_chat)
        await session.commit()

async def get_chats_by_user(email: str, supabase):
    async with async_session() as session:
        result = await session.execute(
            select(Chat).where(Chat.author_email == email)
        )
        return result.scalars().all()

async def get_chat_by_id(chat_id: str, supabase):
    async with async_session() as session:
        result = await session.execute(select(Chat).where(Chat.id == chat_id))
        return result.scalar_one_or_none()