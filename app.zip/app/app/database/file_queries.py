from app.models.file import File
from sqlalchemy.future import select

async def add_file(file_id: str, file_path: str, content: str, author_email: str, supabase):
    new_file = {"id": file_id, "file_path": file_path, "content": content, "author_email": author_email}
    supabase.table("files").insert(new_file).execute()

async def get_files_by_user(email: str, supabase):
    data = supabase.table("files").select("*").eq("author_email", email).execute()
    return data.data if data else []

async def delete_file_by_id(file_id: str, supabase):
    supabase.table("files").delete().eq("id", file_id).execute()
    supabase.storage.from_("pdfs").remove(file_id)