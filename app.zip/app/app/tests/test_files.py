import os
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_upload_file():
    with open("sample.pdf", "wb") as f:
        f.write(b"%PDF-1.4...")  # محتوى ملف PDF
    with open("sample.pdf", "rb") as f:
        response = client.post("/files/upload", files={"file": f})
    assert response.status_code == 200
    assert response.json()["message"] == "File uploaded successfully"
    os.remove("sample.pdf")
