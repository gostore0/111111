



from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.sql import text
import asyncio

# إعداد اتصال قاعدة البيانات

DATABASE_URL = "postgresql+asyncpg://postgres.ntfcbtmrgqjmphpvhcsu:Pdfapp123456##@aws-0-eu-central-1.pooler.supabase.com:5432/postgres"

engine = create_async_engine(DATABASE_URL, echo=True)

async def test_connection():
    try:
        async with engine.begin() as conn:
            # استخدم sqlalchemy.sql.text لإنشاء استعلام SQL
            result = await conn.execute(text("SELECT 1"))
            print("Connection successful:", result.scalar())
    except Exception as e:
        print("Error occurred:", e)

# تشغيل الاختبار
asyncio.run(test_connection())
