from fastapi import APIRouter, HTTPException, Depends
from app.database.queries import create_chat, get_chats_by_user, get_chat_by_id
from app.utils.auth_utils import get_current_user
from uuid import uuid4
from app.features.rag import retrieve_and_generate

chat_router = APIRouter()

# إنشاء محادثة مع RAG
@chat_router.post("/generate")
async def generate_response(prompt: str, user: dict = Depends(get_current_user)):
    response = await retrieve_and_generate(prompt, user["email"])

    chat_id = str(uuid4())
    await create_chat(chat_id, f"User: {prompt}\nAssistant: {response}", user["email"])

    return {"message": "Response generated", "response": response}