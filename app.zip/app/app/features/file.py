from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Form
from app.database.file_queries import add_file, get_files_by_user, delete_file_by_id
from app.utils.pdf_utils import extract_text_from_pdf
from app.utils.auth_utils import get_current_user
from uuid import uuid4
import os

file_router = APIRouter()

UPLOAD_DIR = "uploaded_files"

# رفع ملف جديد
@file_router.post("/upload/")
async def upload_file(
    file: UploadFile = File(...), user: dict = Depends(get_current_user)
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")

    file_id = str(uuid4())
    file_path = os.path.join(UPLOAD_DIR, file_id + "_" + file.filename)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    content = extract_text_from_pdf(file_path)
    await add_file(file_id, file_path, content, user["email"])

    return {"message": "File uploaded successfully", "file_id": file_id}