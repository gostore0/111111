from app.utils.embedding_utils import get_text_embedding
from app.utils.similarity_utils import cosine_similarity
from app.database.file_queries import get_files_by_user
import openai
import os

from app.utils.cache import get_cache, set_cache
from supabase import create_client, Client

url: str = "https://aws-0-eu-central-1.pooler.supabase.com"  # أدخل رابط Supabase الخاص بك
key: str = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50ZmNidG1yZ3FqbXBocHZoY3N1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNTg2NzQ2NSwiZXhwIjoyMDUxNDQzNDY1fQ.MgRMBJi_Zg__hrrJMGZikkIRt-oeGmO9FBef_JyAS5I"  # أدخل مفتاح API الخاص بـ Supabase

supabase: Client = create_client(url, key)

openai.api_key = os.getenv("OPENAI_API_KEY")

async def retrieve_and_generate(prompt: str, user_email: str, selected_files: list = []):
    cache_key = f"rag:{user_email}:{prompt}:{selected_files}"
    cached_response = await get_cache(cache_key)

    if cached_response:
        return cached_response

    files = await get_files_by_user(user_email, supabase)

    if selected_files:
        files = [file for file in files if file["id"] in selected_files]

    if not files:
        return "Please upload and select files to use for answering."

    prompt_embedding = get_text_embedding(prompt)

    relevant_chunks = []
    for file in files:
        file_embedding = get_text_embedding(file["content"])
        similarity = cosine_similarity(prompt_embedding, file_embedding)
        relevant_chunks.append({"content": file["content"], "similarity": similarity})

    relevant_chunks = sorted(relevant_chunks, key=lambda x: x["similarity"], reverse=True)
    context = "\n\n".join([chunk["content"] for chunk in relevant_chunks[:3]])

    response = openai.Completion.create(
        model="text-davinci-003",
        prompt=f"Context:\n{context}\n\nQuestion:\n{prompt}\n\nAnswer:",
        max_tokens=200,
    )["choices"][0]["text"]

    await set_cache(cache_key, response)
    return response