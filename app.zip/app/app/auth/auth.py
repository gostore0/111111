from uuid import uuid4
from fastapi import APIRouter, HTTPException, status, Depends, Form
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.database.database import async_session, init_db
from app.models.user import User
from app.utils.password_utils import hash_password, verify_password
from jose import JWTError, jwt
import os
from datetime import datetime, timedelta
from supabase import create_client, Client

SECRET_KEY = os.getenv("SECRET_KEY", "default_secret_key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

auth_router = APIRouter()

url: str = "https://aws-0-eu-central-1.pooler.supabase.com"  # أدخل رابط Supabase الخاص بك
key: str = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im50ZmNidG1yZ3FqbXBocHZoY3N1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTczNTg2NzQ2NSwiZXhwIjoyMDUxNDQzNDY1fQ.MgRMBJi_Zg__hrrJMGZikkIRt-oeGmO9FBef_JyAS5I"  # أدخل مفتاح API الخاص بـ Supabase

supabase: Client = create_client(url, key)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

@auth_router.post("/register")
async def register_user(email: str = Form(...), password: str = Form(...)):
    hashed_password = hash_password(password)
    try:
        # استخدام uuid4() لتوليد id فريد
        user_id = str(uuid4())
        data = supabase.table("users").insert(
            {"id": user_id, "email": email, "password": hashed_password}
        ).execute()
        if not data:
            raise HTTPException(status_code=400, detail="User already exists")
        return {"message": "User created successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail="User already exists")

@auth_router.post("/login")
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    result = supabase.table("users").select("*").eq("email", form_data.username).execute()
    user = result.data[0] if result.data else None

    if not user or not verify_password(
        form_data.password, user["password"]
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["email"]}, expires_delta=access_token_expires
    )

    return {"access_token": access_token, "token_type": "bearer"}