from sqlalchemy import Column, String, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from app.models.base import Base
from datetime import datetime

# جدول المحادثات
class Chat(Base):
    __tablename__ = "chats"
    id = Column(String, primary_key=True, index=True)  # معرف المحادثة
    created_at = Column(DateTime, default=datetime.utcnow)  # وقت الإنشاء
    messages = Column(Text, nullable=False)  # نص الرسائل (JSON)
    author_email = Column(String, ForeignKey("users.email"))  # صاحب المحادثة

    # العلاقة مع جدول المستخدمين
    author = relationship("User", back_populates="chats")
