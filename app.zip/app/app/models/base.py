from sqlalchemy.orm import declarative_base

# القاعدة لجميع النماذج
Base = declarative_base()
