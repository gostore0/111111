from sqlalchemy import Column, String, Text, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base

# جدول الملفات
class File(Base):
    __tablename__ = "files"
    id = Column(String, primary_key=True, index=True)  # معرف الملف
    file_path = Column(String, nullable=False)  # مسار الملف
    content = Column(Text, nullable=False)  # النص المستخرج
    author_email = Column(String, ForeignKey("users.email"))  # صاحب الملف

    # العلاقة مع جدول المستخدمين
    author = relationship("User", back_populates="files")
