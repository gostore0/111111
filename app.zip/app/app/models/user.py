from sqlalchemy import Column, String
from app.models.base import Base
from sqlalchemy.orm import relationship



# تحديث جدول المستخدمين
class User(Base):
    __tablename__ = "users"
    email = Column(String, primary_key=True, index=True)
    password = Column(String)

    # العلاقات
    chats = relationship("Chat", back_populates="author")
    files = relationship("File", back_populates="author")
