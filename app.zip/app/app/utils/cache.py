import redis
import json
from typing import Optional

# الاتصال بـ Redis
redis_client = redis.StrictRedis(host="localhost", port=6379, decode_responses=True, db=0) #  تمت إضافة `db=0`

# تخزين البيانات في Redis
async def set_cache(key: str, value: str, expire: int = 3600): #  تعديل نوع `value`
    redis_client.set(key, value, ex=expire) #  إزالة `json.dumps`

# استرجاع البيانات من Redis
async def get_cache(key: str) -> Optional[str]: #  تعديل نوع القيمة المعادة
    cached_data = redis_client.get(key)
    return cached_data #  إزالة `json.loads`