import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

# إنشاء تضمين للنصوص باستخدام OpenAI
def get_text_embedding(text: str):
    response = openai.Embedding.create(
        input=text,
        model="text-embedding-ada-002"
    )
    return response["data"][0]["embedding"]
