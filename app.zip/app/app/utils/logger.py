import logging

# إعداد Logger
logger = logging.getLogger("app")
logger.setLevel(logging.INFO)

# إضافة مخرجات للملف
file_handler = logging.FileHandler("app.log")
file_handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))

# إضافة المخرجات إلى logger
logger.addHandler(file_handler)
